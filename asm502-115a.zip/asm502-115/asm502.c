/* ASM502: A Portable simple 6502 assembler. Freeware. (C) A.Millett 1980-2016
  Released as free software under GNU GPL3 license, see GNU website:    www.gnu.org/licenses/gpl-3.0.html 
---------------------------------------------------------------------------------------------------------
  Designed to compile/run on any system, inc C64/Apple2 etc..
  Take tabs from PET "assembler-am"..
->ASM502-100 (31.10.2016)
  Debug until it compiles simple test instructions (asmin.s).. 
->ASM502-101 (1.11.2016)
  Imp hex out. Imp .END, *=$XXXX..
  Working simple 1 pass assembler (no labels/vars)..
->ASM502-102 (1.11.2016)
  Imp asm_outbin, pOutFile - binary dest (.PRG) file.
->ASM502-103 (1.11.2016)
  Imp var_ handling (USE_VAR) from xlcc..
  Imp label/var assignment: VAR: or VAR=xxxx
  Working 2 pass compiler..
->ASM502-104 (1.11.2016)
  Imp parse_Expression - full expression evaluator
->ASM502-105 (2.11.2016)
  Debug.. Working version..
  Imp asm_cmdByte: .$xx  cmd..
->ASM502-106 (2.11.2016)
  Imp .WORD, Debug..
->ASM502-107 (3.11.2016)
  STX wrong, Alter opbase.
  Imp unary expressions: LOBYTE (<) HI (>) NEG(-)
  Imp .BYTE "TEXT"..  .ORG ..
->ASM502-108 (3.11.2016)
  Imp USE_FULL, zero for minimal asm without var/labels.
  Imp .IF/.ENDIF commands. (asm_cmdIf..)
  Imp simple .DEFINE Var Expr (same as Var = Expr..)
->ASM502-109 (3.11.2016)
  Debug .if/else/endif, use a stack.
  Bug: ADC $03,Y fails, Illegal ZP,y should default to ABS,Y
->ASM502-110 (4.11.2016)
  Eval error, ie: VAR=100-10-10-10 wrong (use: oper <= oplevel)
  Eval error: C Type (var == 0) condition is used, asm uses (var = 0) 
  Imp eval ==,!=,<,> ..
->ASM502-111 (5.11.2016)
  Use '=' not '==' for eq test. 
  Reject opcodes within labels.. ie: "STARTPRG:" ; This has STA at start..
  Convert asm_tab_opoffset[] to C-Byte codes..
  Allow lower case (use toupper).
->ASM502-112 (6.11.2016)
  Imp user input if no prg args.
  Imp DEFINT default int type (ie: long, or unsigned short int..)
->ASM502-114 (7.11.2016)
  (2do: LSR A, better error checks, errcodes.. .LO/.HIBYTES, Multistatm lines, Cmd line: -o name, K&R.. *=XXXX behavior. C-Comments?)
->ASM502-115 (10.11.2016)

*/

char szProg[] = "ASM502-1.15: A portable 6502 assembler. (C)A.Millett 1980-2016. Freeware.\n";

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define APP_DEBUG 0
#define USE_FULL  1		/* Enable labels, expressions. 0 for very simple 1-pass assembler */
#define USE_KANDR 0		/* Use old K&R syntax */

unsigned int asm_org = 0;	/* Asm org pointer */
int asm_var_unalloc;		/* Flag set if unalloc var in expression.. */

#define DEFINT unsigned short	/* Default int working unit.. (ie: long, unsigned short..) */

/*---------------------------------------------------------------
  io_  general portable io functions
---------------------------------------------------------------*/

#define TRUE  1
#define FALSE 0

  /* Print a char */
void io_putch (ch) int ch;
{ 
    if (ch == '\n') putchar ('\r');
    putchar (ch);
}

  /* Print a string */
void io_puts (ostr) char *ostr;
{ 
    char ch;
    while (ch = *ostr) {
      io_putch (ch);
      ostr ++;
    }
}

  /* Print an int */
void io_putint (x) int x;
{
    if (x<0) {
      x = -x; io_putch ('-');
    }
    if (x>9) io_putint (x/10);
    io_putch ('0' + x % 10);
}

void io_putsi (ostr, val) char *ostr; int val;
{
    io_puts (ostr);
    io_putint (val); 
}
  
  /* Print a hex number */
void io_puthex (x,ndig) int x,ndig;
{
    int d;
    char ch;
    for (d=ndig; d; d--) {
      ch = (char) ((x >> ((d-1)*4)) & 15)+48;
      if (ch > 57) ch+=7;
      io_putch (ch);
    }
}


/* Search null delim token list (pToken) for string (pFind)
     return token index found, or zero if none. 
     Ret token len in (slen)
     pToken must end with double null.
*/

int io_strToken (char *pToken, char *pFind, int *slen)
{
    char *pStr;
    int ctoken = 0;
    while (*pToken) {
      pStr = pFind;
      ctoken ++;
      while (*pToken == *pFind && *pToken) {
        pToken ++; pStr ++;
      }
      if (*pToken == 0) {	/* Token found */
        if (slen) *slen = (int) ((char *) pStr - pFind);
	return ctoken;
      }
      while (*pToken) pToken ++;
      pToken ++;
    }
    if (slen) *slen = 0;
    return 0;		/* No match */
}

  /* Convert ascii number to DEFINT. *pLen==0 if error */
DEFINT io_asc2int (char *pTxt,  int base, int *pLen, int maxlen)
{
    char ch;
    DEFINT xval = 0;
    int len;
    for (len = 0; len < maxlen; len++) {
      ch = toupper(pTxt[len]);
      if (ch < '0') break;
      if (ch > '9') {
        if (ch < 'A') break;
        ch = ch - 'A' + 58;
      }
      ch -= '0'; if (ch >= base) break;
      xval = xval * base + ch ;
    }
    *pLen = len;
    return xval;
}

/*---------------------------------------------------------------
  var_  variable/identifier assign/find
---------------------------------------------------------------*/

#if USE_FULL

#define VAR_MAX 500	
#define VAR_HEAP 6000		/* Space for all var/label names */
#define VAR_MAXNAME 80

int var_num = 0;		/* no of variables/identifiers */
int var_heappos = 0;		/* current pos in var name heap */

DEFINT var_val   [VAR_MAX];	/* Var val/constant/address.. */
/* int var_type   [VAR_MAX];	 Var type */
int var_pos    [VAR_MAX];	/* Var pos in heap */
char var_heap  [VAR_HEAP];	/* Variable name strings, null term */

  /* Find len of varname/identifier at (pSCode), ret 0 if none */

int var_parse (char *pSCode)
{
    char ch;
    int cpos = 0;

    ch = *pSCode;
    if (isalpha (ch) == 0) return 0;
    while (ch = pSCode [cpos], isalpha (ch) || isdigit (ch) || ch == '_') {
      cpos ++;
    }
    return cpos;
}

  /* Add a variable/identifier to var list */

int var_define (char *szName, unsigned vval)
{
    int clen;
    if (var_num >= VAR_MAX - 2) return -1;
    clen = strlen (szName);
    if (clen < 1 || clen > VAR_MAXNAME) return -1;
    if (var_heappos + clen >= VAR_HEAP - 16) return -1;
    strcpy (var_heap + var_heappos, szName);
    var_val  [var_num] = vval;
    var_pos  [var_num] = var_heappos;
    var_heappos += clen + 1;
    var_num ++;
    return (var_num-1);
}

  /* Find var/id in list (-1 if undef) */

int var_find (char *szName)
{
    int clen,cvar;
    clen = strlen (szName);

    if (clen < 1 || clen > VAR_MAXNAME) return -1;
    cvar = 0;
    while (cvar < var_num) {
      if (strcmp (szName, var_heap + var_pos [cvar]) == 0) {
        return cvar;	/* Found variable.. */
      }
      cvar ++; 
    }
    return -1;
}

  /* Parse & Find var/id in source code */

int var_parse_find (char *pSCode, int assign, unsigned ival)
{
    int cret,clen;
    char ch;
    clen = var_parse (pSCode);
    if (clen == 0) return -1;
    ch = pSCode[clen];
    pSCode[clen] = 0;
    cret = var_find (pSCode);		
    if (assign) {
      if (cret < 0) {		/* Does not exist yet, create? */
        cret = var_define (pSCode, ival);
      } else {
        var_val [cret] = ival;
      }
    }
    pSCode[clen] = ch;
    pSCode += clen;
    return cret;
}

void var_dump ()
{
    int cvar;
    cvar = 0;
    io_puts ("\n");
    while (cvar < var_num) {
      io_puts (var_heap + var_pos [cvar]);
      io_puts (" = $");
      io_puthex (var_val [cvar],4);
      io_puts ("\n");
      cvar ++;
    }
}

void var_init ()
{
    var_num = 0;
    var_heappos = 0;
}

#endif		/* USE_FULL */

/*---------------------------------------------------------------
  parse_  parse expressions (recursive)
---------------------------------------------------------------*/


#if USE_FULL

char szOper[] = "<<\0>>\0=\0!=\0<\0>\0&\0|\0^\0+\0-\0*\0/\0%\0\0";

#define OP_SHL   1
#define OP_SHR   2
#define OP_EQ    3
#define OP_NEQ   4
#define OP_LESS  5
#define OP_MORE  6
#define OP_AND   7
#define OP_OR    8
#define OP_EOR   9
#define OP_ADD  10
#define OP_SUB  11
#define OP_MUL  12
#define OP_DIV  13
#define OP_MOD  14

char *pExp;		/* Ptr to parse string expression */

/* 
   Parse Expression recursively in (pExp) 
*/

DEFINT parse_SubExpression (int oplevel)
{
    DEFINT val,val2;
    char cchr;
    int oper;
    int clen;
    int cvar;
    val = 0;

    while ((cchr = *pExp) == ' ' || cchr == 9) pExp ++;
			/* First parse unary terms.. */
    if (cchr == '(') {		/* Eval expression in brackets.. */
      pExp++;
      val = parse_SubExpression (0);
      if (*pExp != ')') return 0;
      pExp++;
    } else if (isdigit (cchr)) {		/* Numeric constant */
		/* val = (DEFINT) strtod (pExp, &pEnd); */
      val = io_asc2int (pExp, 10, &clen, 11);
      pExp += clen;
    } else if (cchr == '$') {		/* Hex constant */
      pExp ++;
      val = io_asc2int (pExp, 16, &clen, 8);
      pExp += clen;
    } else if (cchr == '%') {		/* Binary constant */
      pExp ++;
      val = io_asc2int (pExp, 2, &clen, 32);
      pExp += clen;
    } else if (cchr == '*') {		/* asm current .ORG pointer */
      pExp ++;
      val = asm_org;
    } else if (isalpha (cchr)) {		/* Variable.. */
      #if USE_FULL
        clen = var_parse (pExp);
        if (clen == 0) return val;
        cvar = var_parse_find (pExp,0,0);
	if (cvar == -1) {	/* Unallocated var */
          asm_var_unalloc = TRUE; 
	  val = 0x4000;		/* Crude way to make unalloc ops ABS (FWD REF) */
	} else {
	  val = var_val [cvar];
	}
	pExp += clen;
      #endif
    } else if (cchr == '<') {		/* Unary expression, Eval Lo Byte (<).. */
      pExp++;
      val = parse_SubExpression (99) & 0xFF;
    } else if (cchr == '>') {		/* Eval Hi Byte (>).. */
      pExp++;
      val = (parse_SubExpression (99) >> 8) & 0xFF;
    } else if (cchr == '-') {		/* Negate (-) Unary expression.. (NOTE:UINT not good for this) */
      pExp++;
      val = 0-parse_SubExpression (99);
    } else {
      return 0;
    }
			/* Now process binary expressions.. */
    while (1) {
      while (*pExp == ' ' || *pExp == 9) pExp ++;
      oper = io_strToken (szOper, pExp, &clen);
      if (oper == 0 || oper <= oplevel) break;
      pExp += clen;
      val2 = parse_SubExpression (oper);
      switch (oper) {
        case OP_SHL:
	  val = ((DEFINT) val) << ((DEFINT) val2); break;
        case OP_SHR:
	  val = ((DEFINT) val) >> ((DEFINT) val2); break;
        case OP_EQ:
	  val = (val == val2); break;
        case OP_NEQ:
	  val = (val != val2); break;
        case OP_LESS:
	  val = (val < val2); break;
        case OP_MORE:
	  val = (val > val2); break;
        case OP_AND:
	  val = ((DEFINT) val) & ((DEFINT) val2); break;
        case OP_OR:
	  val = ((DEFINT) val) | ((DEFINT) val2); break;
        case OP_EOR:
	  val = ((DEFINT) val) ^ ((DEFINT) val2); break;
        case OP_ADD:
	  val += val2; break;
        case OP_SUB:
	  val -= val2; break;
        case OP_MUL:
	  val *= val2; break;
        case OP_DIV:
	  val /= val2; break;
      }
    }
    return val;
}

DEFINT parse_Expression (char *pTxt, int *plen)
{
    DEFINT val;
    asm_var_unalloc = FALSE;
    pExp = pTxt;
    val = parse_SubExpression (0);
    if (plen) *plen = (int) ((char *) pExp - pTxt);	/* Calc len */
    return val;
}

#endif		/* USE_FULL */

/*---------------------------------------------------------------
  asm_  assembly routines/vars
---------------------------------------------------------------*/

#define MAX_IN 248

char *pOutFile = NULL;
FILE *hOutFile = NULL;

char asm_szSrc[100];		/* Source file name */
char asm_szDest[100];		/* Dest file name */

char asm_szTxt[MAX_IN+4];
int tpos;

unsigned int asm_eval;		/* Eval result */

#define MAX_OUTBYTE 100
int asm_nOutByte;
unsigned char asm_outByte[MAX_OUTBYTE+2];	/* Bytes to be written to output */

int asm_txtline;
char asm_opPre;
int asm_opgroup;	/* opcode Group */
int asm_opbase;		/* base for opcode */
int asm_oplen;		/* Oprand len */
int asm_pass;
int asm_npass;		/* #passes to perform */

#define MAX_OPCODE 56

   /* 6502 opcodes stored in 1 string in alphabetic order. */
char asm_szOpcode[] = 
  "ADCANDASLBCCBCSBEQBITBMIBNEBPLBRKBVCBVSCLCCLDCLICLVCMPCPXCPYDECDEXDEY"
  "EORINCINXINYJMPJSRLDALDXLDYLSRNOPORAPHAPHPPLAPLPROLRORRTIRTS"
  "SBCSECSEDSEISTASTXSTYTAXTAYTSXTXATXSTYAERR";

  /* Base for each opcode, (ADC..TYA) bits changed for different modes */
unsigned char asm_tab_opbase[] = {
  0x69,0x29,0x0A,0x90,0xB0,0xF0,0x28,0x30, 0xD0,0x10,0x00,0x50,0x70,0x18,0xD8,0x58,
  0xB8,0xC9,0xE0,0xC0,0xCA,0xCA,0x88,0x49, 0xEA,0xE8,0xC8,0x4C,0x20,0xA9,0xA2,0xA0,
  0x4A,0xEA,0x09,0x48,0x08,0x68,0x28,0x2A, 0x6A,0x40,0x60,0xE9,0x38,0xF8,0x78,0x89,
  0x8A,0x84,0xAA,0xA8,0xBA,0x8A,0x9A,0x98, 0x02,0};

  /* Group-type for each opcode (ie: 0=Modeless, 1=Branch, 2=Arithmetic, 3=BitShift, etc) (was LG) */
unsigned char asm_tab_opgroup[] = {
  2,2,3,1,1,1,4,1,1,1,0,1,1,0,0,0,0,2,5,5,6,0,0,2,6,0,0,7,8,2,9,13,
  3,0,2,0,0,0,0,3,3,0,0,2,0,0,0,10,10,12,0,0,0,0,0,0,0};

#define GRP_MODELESS 0
#define GRP_BRANCH   1
#define GRP_ARITH    2
#define GRP_BITSH    3

  /* Len of oprand for given mode */
unsigned int asm_tab_oplen [] = {0,1,1,1,1,1,2,2,2,1,1,2};

  /* Operator legality/mask tables, to be added with asm_opbase, 0xFF (_I__) =illegal combination 
        14 groups each with 12 modes, index = (asm_opgroup*12 + opmode-1) */

#define _I__ 0xFF		/* Illegal op mode/base combo flag */

unsigned char asm_tab_opoffset[] = {
  0x00, _I__, _I__, _I__, _I__, _I__, _I__, _I__, _I__, _I__, _I__, _I__, 
  _I__, 0x00, _I__, _I__, _I__, _I__, _I__, _I__, _I__, _I__, _I__, _I__, 
  _I__, _I__, 0x00, 0xfc, 0x0c, _I__, 0x04, 0x14, 0x10, 0xf8, 0x08, _I__, 
  0x00, _I__, _I__, 0xfc, 0x0c, _I__, 0x04, 0x14, _I__, _I__, _I__, _I__, 
  _I__, _I__, _I__, 0xfc, _I__, _I__, 0x04, _I__, _I__, _I__, _I__, _I__, 
  _I__, _I__, 0x00, 0x04, _I__, _I__, 0x0c, _I__, _I__, _I__, _I__, _I__, 
  _I__, _I__, _I__, 0xfc, 0x0c, _I__, 0x04, 0x14, _I__, _I__, _I__, _I__, 
  _I__, _I__, _I__, _I__, _I__, _I__, 0x00, _I__, _I__, _I__, _I__, 0x20, 
  _I__, _I__, _I__, _I__, _I__, _I__, 0x00, _I__, _I__, _I__, _I__, _I__, 
  _I__, _I__, 0x00, 0x04, _I__, 0x14, 0x0c, _I__, 0x1c, _I__, _I__, _I__, 
  _I__, _I__, _I__, 0xfc, 0x0c, _I__, 0x04, 0x14, 0x10, 0xf8, 0x08, _I__, 
  _I__, _I__, _I__, 0x10, _I__, 0x14, 0x0c, _I__, _I__, _I__, _I__, _I__, 
  _I__, _I__, _I__, 0x00, 0x10, _I__, 0x08, _I__, _I__, _I__, _I__, _I__, 
  _I__, _I__, 0x00, 0x04, 0x14, _I__, 0x0c, 0x1c, _I__, _I__, _I__, _I__};

/* ORIG PET: char asm_tab_opoffset[] =
  "@XXXXXXXXXXX" "X@XXXXXXXXXX" "XX@?CXAED>BX" "@XX?CXAEXXXX" "XXX?XXAXXXXX"
  "XX@AXXCXXXXX" "XXX?CXAEXXXX" "XXXXXX@XXXXH" "XXXXXX@XXXXX" "XX@AXECXGXXX"
  "XXX?CXAED>BX" "XXXDXECXXXXX" "XXX@DXBXXXXX" "XX@AEXCGXXXX";  */

int asm_errorcode;	/* Assem error code */

#define ASM_OK           0
#define ASM_SYNTAX_ERR   1
#define ASM_OPMODE_ERR   2
#define ASM_OVERFLOW     3

  /* Get next non-space char */
char asm_nextChar ()
{
    char ch;
    while (1) {
      ch = asm_szTxt[tpos];
      if (ch != ' ' && ch != 9 && ch != 10) {
        return ch;
      }
      tpos ++;
    }
    return ch;
}

  /* Does string match? */
int asm_IsMatch (char *pTxt)
{
    int x;
    x=0;
    while (pTxt[x]) {
      if (pTxt[x] != toupper(asm_szTxt[tpos+x])) return FALSE;
      x ++;
    }
    return TRUE;
}

  /* Search for ascii opcode, ret -1 if no match */
int asm_FindOpcode (char *pTxt)
{
    int op,cpos;
    char ch1,ch2,ch3;
    ch1 = toupper (*pTxt); ch2 = toupper (pTxt[1]); ch3 = toupper (pTxt[2]);
    cpos = 0;
    for (op = 0; op < MAX_OPCODE; op++) {
      if (ch1 == asm_szOpcode[cpos] && ch2 == asm_szOpcode[cpos+1] && ch3 == asm_szOpcode[cpos+2]) {
        return op;
      }
      cpos += 3;
    }
    return -1;		/* none found */
}

  /* Parse pre-expression address mode chars: "#(A", 0 if none. */
char asm_ParsePreMode ()
{
    char pre,ch;
    pre = asm_nextChar ();
    if (pre == '#' || pre == '(') {	/* ie: LDA #, LDA (pos),Y.. */
      tpos ++ ; return pre;
    }
    if (pre == 'A') {			/* ie: ROR A.. */
      ch = asm_szTxt [tpos + 1];		/* Whitespace must follow */
      if (ch == 0 || ch == ':' || ch == ';' || ch == ' ') {
        tpos ++ ; return pre;
      }
    }
    return 0;
}

#if USE_FULL

  /* Recursively parse a complex expression */
int asm_EvalExpression ()
{
    int clen;
    asm_var_unalloc = FALSE;
    asm_eval = (unsigned int) parse_Expression (asm_szTxt + tpos, &clen);
    if (clen == 0) return FALSE;
    tpos += clen;
    return TRUE;
}

#else		/* USE_FULL */

  /* Simple Eval number (asm_eval) */
int asm_EvalExpression ()
{
    int clen;
    char ch;
    asm_var_unalloc = FALSE;
    ch = asm_nextChar ();
    if (ch == '$') {
      tpos ++;
      asm_eval = io_asc2int (asm_szTxt + tpos, 16, &clen, 4);
    } else {
      asm_eval = io_asc2int (asm_szTxt + tpos, 10, &clen, 5);
    }
    if (clen == 0) return FALSE;
    tpos += clen;
    ch = asm_nextChar ();
    return TRUE;
}

#endif		/* USE_FULL */

  /* Parse opcode mode from source */
int asm_ParseMode ()
{
    int mod;
    if ((asm_opgroup == GRP_MODELESS || asm_opgroup == GRP_BITSH) && asm_eval == 0) return 1;
    if (asm_opPre == '#') return 3;			/* Immediate mode */
    if (asm_opPre == '(') {
      if (asm_IsMatch (",X)")) {		/* MODE (ZP,X) */
        tpos += 3; return 10;
      }
      if (asm_IsMatch ("),Y")) {		/* MODE (ZP),Y */
        tpos += 3; return 11;
      }
      if (asm_IsMatch (")")) {		/* JMP () indirect */
        tpos += 1; return 12;
      }
    }
    if (asm_opPre != 0) return -1;	/* Otherwise must have no asm_opPre-mode */

    if (asm_opgroup == GRP_BRANCH) {	/* Branch instuction */
      asm_eval = asm_eval - asm_org - 2;	/* Calc offset */
      if (asm_eval < 0 || asm_eval > 256) asm_eval += 256;
      return 2;
    }
      /* Size of (asm_eval) determines zero or absolute addr. */
    mod = 0;				/* ZeroPage mods (4,5,6) */
    if (asm_var_unalloc || asm_eval > 255) mod = 3;	/* ABS modes (7,8,9) */
    if (asm_IsMatch (",X")) {
      tpos += 2; return mod + 5;
    }
    if (asm_IsMatch (",Y")) {
      tpos += 2; return mod + 6;
    }
    return mod + 4;	/* Default abs/zero page */
}

  /* Parse an opcode & expression.. Gen asm_outByte[asm_nOutByte], or FALSE if err..  */
int asm_ParseOpcode ()
{
    int op;
    int opmode,opoffset;
    int exret;
    asm_eval = 0;
    op = asm_FindOpcode (asm_szTxt + tpos);
    if (op < 0) return FALSE;
    tpos += 3;
    if (isalpha (asm_szTxt [tpos])) return FALSE;	/* Dont allow opcode in longer names.. */
    asm_opbase = asm_tab_opbase [op];
    asm_opgroup = asm_tab_opgroup [op];
    asm_opPre = asm_ParsePreMode ();
    exret = asm_EvalExpression ();
    opmode = asm_ParseMode ();
    #if APP_DEBUG
      io_putsi (" (base:",asm_opbase); io_putsi (" group:",asm_opgroup);
      io_putsi (" pre:",asm_opPre); io_putsi (" mode:",opmode); io_putsi (" asm_eval:",asm_eval);
      io_puts (") ");
    #endif
    asm_errorcode = ASM_OPMODE_ERR;
    if (opmode < 0) return FALSE;
    opoffset = asm_tab_opoffset[asm_opgroup * 12 + opmode-1];
    if (opoffset == _I__) {		/* Illegal group/mode combo? */
      if (opmode < 4 || opmode > 6) return FALSE;
      opmode += 3;
      opoffset = asm_tab_opoffset[asm_opgroup * 12 + opmode-1];    /* Try non-ZP mode*/
      if (opoffset == _I__) return FALSE;
    }
    asm_oplen = asm_tab_oplen[opmode-1];
    asm_outByte[0] = (asm_opbase + opoffset) & 255;		/* Calculate actual opcode */
		/* Does expression match required oprand length? */
    asm_nOutByte = 1 + asm_oplen;
    if (asm_oplen == 0) {
      if (asm_eval || exret) return FALSE;		/* Must have no oprand */
      return TRUE;
    }
    asm_outByte[1] = asm_eval & 255;
    if (exret == FALSE) return TRUE;
    if (asm_oplen == 1) {
      if (asm_eval>255 && asm_pass == asm_npass) return FALSE;	/* Must have 1 byte opr */
      return TRUE;
    }
    asm_outByte[2] = asm_eval >> 8;
    return TRUE;
}

  /* Output binary data */
int asm_outbin (unsigned char *pData, int nbytes) 
{
    int nwrt;
    if (hOutFile == NULL) return TRUE;
    nwrt = fwrite (pData, 1, nbytes, hOutFile);
    return (nwrt == nbytes);
}

  /* Output compiled code */
int asm_output ()
{
    int x;
    if (asm_pass < asm_npass) return TRUE;
    io_puthex (asm_org,4);
    for (x=0; x < asm_nOutByte; x++) {
      io_puts (" ");
      io_puthex (asm_outByte[x],2);
    }
    for (; x < 3; x++) io_puts ("   ");
    io_puts (" ;");
    io_puts (asm_szTxt);
    return asm_outbin (asm_outByte, asm_nOutByte);
}

  /* Set asm org pointer, loc to compile code */
int asm_setOrg ()
{
    int cret;
    cret = asm_EvalExpression ();
    if (cret == FALSE) return FALSE;
    asm_org = asm_eval;
    asm_outByte[0] = asm_eval & 255;
    asm_outByte[1] = asm_eval >> 8;
    if (asm_pass < asm_npass) return TRUE;
    return asm_outbin (asm_outByte, 2);
}


int asm_cmdByte (int wordflag)
{
    int cret;
    char ch;
    int nbyte = 0;
    do {
      ch = asm_nextChar ();
      if (ch == 34) {
        tpos ++;
	while (asm_nOutByte < MAX_OUTBYTE) {
	  ch = asm_szTxt[tpos];
	  if (ch == 0) return FALSE;
	  tpos ++;
	  if (ch == 34) break;
          asm_outByte [nbyte] = ch;
          nbyte ++; 
	}
      } else {
        cret = asm_EvalExpression ();
        if (cret == FALSE) return FALSE;
        asm_outByte [nbyte] = asm_eval & 255;
        nbyte ++;
        if (wordflag) {
          asm_outByte [nbyte] = asm_eval >> 8;
          nbyte ++;
        } else {
          if (asm_eval >> 8) return FALSE;	/* Byte overflow */
        }
      }
      ch = asm_nextChar ();
      if (ch != ',') break;
      tpos ++;	
    } while (asm_nOutByte < MAX_OUTBYTE);
    asm_nOutByte += nbyte;
    asm_output ();
    asm_org += asm_nOutByte;
    return TRUE;
}


#if USE_FULL

  /* Set label/var, ie LABLE: or VAR=val.. */

int asm_setLabel (int mode)
{
    int cvar,clen,varpos;
    int cret;
    char ch;
    varpos = tpos;
    clen = var_parse (asm_szTxt + tpos);
    if (clen == 0) return FALSE;
    tpos += clen;
    ch = asm_nextChar ();
    if (mode) {
      cret = asm_EvalExpression ();
      if (cret == FALSE) return FALSE;
    } else if (ch == '=') {		/* VAR=expr.. */
      tpos ++;
      cret = asm_EvalExpression ();
      if (cret == FALSE) return FALSE;
    } else if (ch == '.' || ch == ':') {	/* LABEL: or LABEL. */
      tpos ++;
      asm_eval = asm_org;
    } else {
      return FALSE;
    }
    cvar = var_parse_find (asm_szTxt + varpos, 1, asm_eval);
    if (cvar == -1) return FALSE;
    asm_nOutByte = 0;
    asm_output ();
    return TRUE;
}

  /* Command: .DEFINE var (expression) */
int asm_cmdDefine ()
{
    char ch = asm_nextChar ();
    if (isalpha(ch) == FALSE) return FALSE;
    return asm_setLabel (1);
}

#define MAX_IF_NEST 16

  /* Use a stack to deal with nested .if/else/endif. 
    asm_disable: (Values 0..3: bit 0=cur if, bit 1= previous level) 
    Dont compile if either bit set. */
int asm_disable = 0;
int asm_if_stack [MAX_IF_NEST+1];
int asm_if_depth = 0;

  /* Command: .IF (expression) */
int asm_cmdIf ()
{
    int cret;
    cret = asm_EvalExpression ();
    if (cret == FALSE) return FALSE;
    if (asm_var_unalloc) asm_eval = 0;		/* expression FALSE if using unalloc var */
    if (asm_if_depth >= MAX_IF_NEST) return FALSE;	/* .IF nested too deep.. */
    asm_if_stack [asm_if_depth] = asm_disable;
    asm_if_depth ++;
    asm_disable = ((asm_disable > 0) << 1) + (asm_eval == 0);   /* (Values 0..3: bit 0=cur if, bit 1= prev level) */
    return TRUE;
}

  /* Command: .ELSE  */
int asm_cmdElse ()
{
    if (asm_if_depth <= 0) return FALSE;
    asm_disable = asm_disable ^ 1;		/* Flip current .IF level bit */
    return TRUE;
}

  /* Command: .ENDIF  */
int asm_cmdEndIf ()
{
    if (asm_if_depth <= 0) return FALSE;
    asm_if_depth --;
    asm_disable = asm_if_stack [asm_if_depth];
    return TRUE;
}

#endif

  /* Assemble a line of source code. ret FALSE if error.. */
int asm_line ()
{
    int cret;
    int lastpos;
    char ch;
    asm_txtline ++;
    asm_errorcode = ASM_SYNTAX_ERR;
    tpos = 0;
    asm_nOutByte = 0;
    ch = asm_nextChar ();
    if (ch == 0 || ch == 13 || ch == 10) return TRUE;
    lastpos = tpos;

    #if USE_FULL
      if (asm_IsMatch (".IF")) {
        tpos += 3;
        return asm_cmdIf ();
      }
      if (asm_IsMatch (".ELSE")) {
        tpos += 5;
        return asm_cmdElse ();
      }
      if (asm_IsMatch (".ENDIF")) {
        tpos += 6;
        return asm_cmdEndIf ();
      }

      if (asm_disable) return TRUE;	/* Skip unused .IF lines.. */

      if (asm_IsMatch (".DEFINE")) {
        tpos += 7;
        return asm_cmdDefine ();
      }
    #endif

    if (ch == ';' || ch == 0) {	/* Comment or End of line.. */
      return TRUE;
    }
    if (asm_IsMatch ("*=")) {		/* Assign current pointer */
      tpos += 2;
      return asm_setOrg ();
    }
    if (asm_IsMatch (".ORG")) {		/* Assign current pointer */
      tpos += 4;
      return asm_setOrg ();
    }
    if (asm_IsMatch (".BYTE")) {		/* .BYTE val,val.. */
      tpos += 5;
      return asm_cmdByte (0);
    }
    if (asm_IsMatch (".WORD")) {		/* .WORD val,val.. */
      tpos += 5;
      return asm_cmdByte (1);
    }
    if (asm_IsMatch (".END")) {
      return -1;
    }

    if (isalpha (ch)) {			/* Alpha char, so its an opcode or label.. */
      cret = asm_ParseOpcode ();
      if (cret == TRUE) {		/* Legal opcode/opand.. */
        asm_output ();
        asm_org += asm_nOutByte;
      } else {
        tpos = lastpos;		/* Move back to start */
        ch = asm_szTxt[tpos];
        #if USE_FULL
	  return asm_setLabel (0);
	#endif
        return FALSE;      
      }
    } else {			/* No legal match found, error.. */
      return FALSE;
    } 
    return TRUE;
}

  /* Assemble source (szFile) */
int asm_file (char *szFile)
{
    int cret;
    FILE *hFile;
    if (pOutFile) {
      hOutFile = fopen (pOutFile,"wb");
      if (hOutFile == NULL) {
        return FALSE;
      }
    }
    #if USE_FULL
      var_init ();
    #endif

    asm_npass = 1 + USE_FULL;	
    for (asm_pass = 1; asm_pass <= asm_npass; asm_pass++) {
      asm_org = 0;

      #if USE_FULL
        asm_disable = FALSE;		/* Enable compile */
        asm_if_depth = 0;
      #endif

      io_putsi ("Pass:",asm_pass); io_puts ("\n\n");
      hFile = fopen (szFile,"rb");
      if (hFile == NULL) {
        io_puts ("File not found\n");
        goto asm_error;
      }
      asm_txtline = 0;
      while (1) {
        if (fgets (asm_szTxt, MAX_IN, hFile) == NULL) break;	/* End of file */
        cret = asm_line ();
	if (cret < 0) break;		/* .END command */
	if (cret == FALSE) {
          #if USE_FULL
            var_dump ();
          #endif
		/* No matching cmd, error.. */
          io_putsi ("Error ",asm_errorcode); io_putsi (" on line:",asm_txtline); 
	  io_putsi (" Col:",tpos); 
	  io_puts (" ->"); io_puts (asm_szTxt); io_puts ("\n");
	  goto asm_error;
	}
      }
      fclose (hFile);
    }
    #if USE_FULL
      var_dump ();
    #endif
    if (hOutFile) {
      fclose (hOutFile);
    }
    return TRUE;

asm_error:
    if (hOutFile) {
      fclose (hOutFile);
    }
    return FALSE;
}

int main (int argc, char *argv[])
{
    pOutFile = NULL;
    io_puts (szProg);

    if (argc < 2) {		/* No params, input from user.. */
      io_puts ("Source:");
      gets (asm_szSrc);		/* Yeah, I know. */
      if (asm_szSrc[0] == 0) {
        return !asm_file ("asmin.s");
      }
      io_puts ("Dest:");
      gets (asm_szDest);
      if (asm_szDest[0]) pOutFile = asm_szDest;
      return !asm_file (asm_szSrc);
    }
    if (argc > 2) {
      pOutFile = argv[2];
    }
    return !asm_file (argv[1]);
}
